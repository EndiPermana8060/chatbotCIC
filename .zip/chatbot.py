import torch
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate
import mysql.connector
import os
from dotenv import load_dotenv

load_dotenv()
GROQ_API_KEY = os.getenv('GROQ_API_KEY')

class DataRecapper:
    def __init__(self):
        self.llm = ChatGroq(groq_api_key=GROQ_API_KEY, model_name="llama-3.1-70b-versatile")
        self.gen_query_template = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    "you are a very helpful assistant that can generate SQL query syntax based on the table that has attributes 'STATE', 'CONTAINER', 'TGL. STATUS', 'JML. HARI', 'OWNER', 'BOOKNO', 'LOGISTIC', 'VESSEL TERAKHIR', 'TGL FXD', 'CY BLOCK', 'OPB ID', 'SHIP. TERAKHIR', 'CONS. TERAKHIR', 'CARGO TERAKHIR', 'TYPE', 'LOKASI', 'REMARK', 'FINDING DAMAGE', 'CROSS CHECK', 'MLO FREEUSER', 'USER_ID', 'NO. SEAL', ''CONTAINER GRADE"
                ),
                ("human","input:\n{text}\n please generate the query syntax based on that request, only the query no need redundant explanation")
            ]
        )
        self.generate_query_chain = self.gen_query_template | self.llm

    def generate_query(self, prompt):
        response = self.generate_query_chain.invoke({'text':prompt}).content
        return response       

