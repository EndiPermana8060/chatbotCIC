from flask import Flask, request, jsonify
from chatbot import DataRecapper
import re

app = Flask(__name__)

processor = DataRecapper()

# Updated regex pattern to match SQL queries starting with common SQL keywords
SQL_REGEX = r"(SELECT).*?;"

@app.route('/')
def index():
    # return render_template('index.html')
    pass

@app.route('/gen_query', methods=['POST'])
def generate_sql_query():
    # Get the user input
    user_prompt = request.json.get('userMessage')

    # Process the input with your LLM or processor
    response = processor.generate_query(user_prompt)

    # Use regex to extract the SQL query portion (from the first SQL keyword till semicolon)
    match = re.search(SQL_REGEX, response, re.IGNORECASE | re.DOTALL)
    if match:
        sql_query = match.group(0).strip()  # Extract the entire query till the semicolon
        return jsonify({'response': sql_query})

    return jsonify({'error': 'No SQL query found in the response'}), 400

@app.route('/summarize', methods=['POST'])
def generate_summary():
    pass

if __name__ == '__main__':
    app.run(debug=True)
